<?php

use Symfony\Component\DependencyInjection\Argument\RewindableGenerator;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\DependencyInjection\Exception\InvalidArgumentException;
use Symfony\Component\DependencyInjection\Exception\LogicException;
use Symfony\Component\DependencyInjection\Exception\RuntimeException;
use Symfony\Component\DependencyInjection\ParameterBag\FrozenParameterBag;
use Symfony\Component\DependencyInjection\ParameterBag\ParameterBagInterface;

/**
 * This class has been auto-generated
 * by the Symfony Dependency Injection Component.
 *
 * @final
 */
class AppDIContainer extends Container
{
    private $parameters = [];

    public function __construct()
    {
        $this->parameters = $this->getDefaultParameters();

        $this->services = $this->privates = [];
        $this->methodMap = [
            'App\\Controllers\\AdminController' => 'getAdminControllerService',
            'App\\Controllers\\AssetController' => 'getAssetControllerService',
            'App\\Controllers\\CategoryController' => 'getCategoryControllerService',
            'App\\Controllers\\CommentController' => 'getCommentControllerService',
            'App\\Controllers\\HomeController' => 'getHomeControllerService',
            'App\\Controllers\\PostController' => 'getPostControllerService',
            'App\\Middlewares\\AdminAuth' => 'getAdminAuthService',
            'App\\Middlewares\\CsrfVerify' => 'getCsrfVerifyService',
            'App\\Route\\ErrorView' => 'getErrorViewService',
            'Symfony\\Component\\HttpFoundation\\Request' => 'getRequestService',
            'Symfony\\Component\\HttpFoundation\\Response' => 'getResponseService',
        ];

        $this->aliases = [];
    }

    public function compile(): void
    {
        throw new LogicException('You cannot compile a dumped container that was already compiled.');
    }

    public function isCompiled(): bool
    {
        return true;
    }

    public function getRemovedIds(): array
    {
        return [
            'App\\DbConfig\\MySqli' => true,
            'App\\Models\\Admin' => true,
            'App\\Models\\Category' => true,
            'App\\Models\\Comment' => true,
            'App\\Models\\Home' => true,
            'App\\Models\\Post' => true,
            'App\\Models\\UserModel' => true,
            'App\\Util\\AppSession' => true,
            'App\\Util\\Trans' => true,
            'App\\View\\FrontRenderInterface' => true,
            'Hashids\\Hashids' => true,
            'League\\Plates\\Engine' => true,
            'Psr\\Container\\ContainerInterface' => true,
            'Symfony\\Component\\DependencyInjection\\ContainerInterface' => true,
            'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface' => true,
            'session_attrbag' => true,
            'session_storage' => true,
        ];
    }

    /**
     * Gets the public 'App\Controllers\AdminController' shared autowired service.
     *
     * @return \App\Controllers\AdminController
     */
    protected function getAdminControllerService()
    {
        return $this->services['App\\Controllers\\AdminController'] = new \App\Controllers\AdminController(($this->services['Symfony\\Component\\HttpFoundation\\Request'] ?? $this->getRequestService()), ($this->privates['App\\View\\FrontRenderInterface'] ?? $this->getFrontRenderInterfaceService()), ($this->privates['Hashids\\Hashids'] ?? ($this->privates['Hashids\\Hashids'] = new \Hashids\Hashids('4e46c93890f89ff4dd3e41513c377ba11fa495a42d26ab1342c49086ae7c630fc91e0d', 5))), ($this->privates['App\\Util\\AppSession'] ?? $this->getAppSessionService()), new \App\Models\Admin(($this->privates['App\\DbConfig\\MySqli'] ?? $this->getMySqliService())));
    }

    /**
     * Gets the public 'App\Controllers\AssetController' shared autowired service.
     *
     * @return \App\Controllers\AssetController
     */
    protected function getAssetControllerService()
    {
        return $this->services['App\\Controllers\\AssetController'] = new \App\Controllers\AssetController();
    }

    /**
     * Gets the public 'App\Controllers\CategoryController' shared autowired service.
     *
     * @return \App\Controllers\CategoryController
     */
    protected function getCategoryControllerService()
    {
        return $this->services['App\\Controllers\\CategoryController'] = new \App\Controllers\CategoryController(($this->services['Symfony\\Component\\HttpFoundation\\Request'] ?? $this->getRequestService()), ($this->privates['App\\View\\FrontRenderInterface'] ?? $this->getFrontRenderInterfaceService()), ($this->privates['Hashids\\Hashids'] ?? ($this->privates['Hashids\\Hashids'] = new \Hashids\Hashids('4e46c93890f89ff4dd3e41513c377ba11fa495a42d26ab1342c49086ae7c630fc91e0d', 5))), ($this->privates['App\\Util\\AppSession'] ?? $this->getAppSessionService()), ($this->privates['App\\Models\\Category'] ?? $this->getCategoryService()), ($this->privates['App\\Models\\Post'] ?? $this->getPostService()));
    }

    /**
     * Gets the public 'App\Controllers\CommentController' shared autowired service.
     *
     * @return \App\Controllers\CommentController
     */
    protected function getCommentControllerService()
    {
        return $this->services['App\\Controllers\\CommentController'] = new \App\Controllers\CommentController(($this->services['Symfony\\Component\\HttpFoundation\\Request'] ?? $this->getRequestService()), ($this->privates['App\\View\\FrontRenderInterface'] ?? $this->getFrontRenderInterfaceService()), new \App\Models\Comment(($this->privates['App\\DbConfig\\MySqli'] ?? $this->getMySqliService())), ($this->privates['Hashids\\Hashids'] ?? ($this->privates['Hashids\\Hashids'] = new \Hashids\Hashids('4e46c93890f89ff4dd3e41513c377ba11fa495a42d26ab1342c49086ae7c630fc91e0d', 5))), ($this->privates['App\\Util\\AppSession'] ?? $this->getAppSessionService()));
    }

    /**
     * Gets the public 'App\Controllers\HomeController' shared autowired service.
     *
     * @return \App\Controllers\HomeController
     */
    protected function getHomeControllerService()
    {
        return $this->services['App\\Controllers\\HomeController'] = new \App\Controllers\HomeController(($this->services['Symfony\\Component\\HttpFoundation\\Request'] ?? $this->getRequestService()), ($this->privates['App\\View\\FrontRenderInterface'] ?? $this->getFrontRenderInterfaceService()), ($this->privates['Hashids\\Hashids'] ?? ($this->privates['Hashids\\Hashids'] = new \Hashids\Hashids('4e46c93890f89ff4dd3e41513c377ba11fa495a42d26ab1342c49086ae7c630fc91e0d', 5))), new \App\Models\Home(($this->privates['App\\DbConfig\\MySqli'] ?? $this->getMySqliService())), ($this->privates['App\\Models\\Post'] ?? $this->getPostService()), ($this->privates['App\\Util\\AppSession'] ?? $this->getAppSessionService()));
    }

    /**
     * Gets the public 'App\Controllers\PostController' shared autowired service.
     *
     * @return \App\Controllers\PostController
     */
    protected function getPostControllerService()
    {
        return $this->services['App\\Controllers\\PostController'] = new \App\Controllers\PostController(($this->services['Symfony\\Component\\HttpFoundation\\Request'] ?? $this->getRequestService()), ($this->privates['App\\View\\FrontRenderInterface'] ?? $this->getFrontRenderInterfaceService()), ($this->privates['App\\Models\\Post'] ?? $this->getPostService()), ($this->privates['Hashids\\Hashids'] ?? ($this->privates['Hashids\\Hashids'] = new \Hashids\Hashids('4e46c93890f89ff4dd3e41513c377ba11fa495a42d26ab1342c49086ae7c630fc91e0d', 5))), ($this->privates['App\\Util\\AppSession'] ?? $this->getAppSessionService()), ($this->privates['App\\Models\\Category'] ?? $this->getCategoryService()));
    }

    /**
     * Gets the public 'App\Middlewares\AdminAuth' shared autowired service.
     *
     * @return \App\Middlewares\AdminAuth
     */
    protected function getAdminAuthService()
    {
        return $this->services['App\\Middlewares\\AdminAuth'] = new \App\Middlewares\AdminAuth(($this->services['Symfony\\Component\\HttpFoundation\\Request'] ?? $this->getRequestService()), ($this->privates['App\\Util\\AppSession'] ?? $this->getAppSessionService()));
    }

    /**
     * Gets the public 'App\Middlewares\CsrfVerify' shared autowired service.
     *
     * @return \App\Middlewares\CsrfVerify
     */
    protected function getCsrfVerifyService()
    {
        return $this->services['App\\Middlewares\\CsrfVerify'] = new \App\Middlewares\CsrfVerify(($this->services['Symfony\\Component\\HttpFoundation\\Request'] ?? $this->getRequestService()), ($this->privates['App\\Util\\AppSession'] ?? $this->getAppSessionService()));
    }

    /**
     * Gets the public 'App\Route\ErrorView' shared autowired service.
     *
     * @return \App\Route\ErrorView
     */
    protected function getErrorViewService($lazyLoad = true)
    {
        return $this->services['App\\Route\\ErrorView'] = new \App\Route\ErrorView(($this->privates['App\\View\\FrontRenderInterface'] ?? $this->getFrontRenderInterfaceService()));
    }

    /**
     * Gets the public 'Symfony\Component\HttpFoundation\Request' shared autowired service.
     *
     * @return \Symfony\Component\HttpFoundation\Request
     */
    protected function getRequestService()
    {
        return $this->services['Symfony\\Component\\HttpFoundation\\Request'] = \Symfony\Component\HttpFoundation\Request::createFromGlobals();
    }

    /**
     * Gets the public 'Symfony\Component\HttpFoundation\Response' shared autowired service.
     *
     * @return \Symfony\Component\HttpFoundation\Response
     */
    protected function getResponseService()
    {
        return $this->services['Symfony\\Component\\HttpFoundation\\Response'] = new \Symfony\Component\HttpFoundation\Response();
    }

    /**
     * Gets the private 'App\DbConfig\MySqli' shared autowired service.
     *
     * @return \App\DbConfig\MySqli
     */
    protected function getMySqliService($lazyLoad = true)
    {
        return $this->privates['App\\DbConfig\\MySqli'] = new \App\DbConfig\MySqli();
    }

    /**
     * Gets the private 'App\Models\Category' shared autowired service.
     *
     * @return \App\Models\Category
     */
    protected function getCategoryService()
    {
        return $this->privates['App\\Models\\Category'] = new \App\Models\Category(($this->privates['App\\DbConfig\\MySqli'] ?? $this->getMySqliService()));
    }

    /**
     * Gets the private 'App\Models\Post' shared autowired service.
     *
     * @return \App\Models\Post
     */
    protected function getPostService()
    {
        return $this->privates['App\\Models\\Post'] = new \App\Models\Post(($this->privates['App\\DbConfig\\MySqli'] ?? $this->getMySqliService()));
    }

    /**
     * Gets the private 'App\Util\AppSession' shared autowired service.
     *
     * @return \App\Util\AppSession
     */
    protected function getAppSessionService()
    {
        return $this->privates['App\\Util\\AppSession'] = new \App\Util\AppSession(new \Symfony\Component\HttpFoundation\Session\Session(new \Symfony\Component\HttpFoundation\Session\Storage\NativeSessionStorage($this->parameters['session_options']), new \Symfony\Component\HttpFoundation\Session\Attribute\AttributeBag()), ($this->services['Symfony\\Component\\HttpFoundation\\Request'] ?? $this->getRequestService()), 1800);
    }

    /**
     * Gets the private 'App\Util\Trans' shared autowired service.
     *
     * @return \App\Util\Trans
     */
    protected function getTransService($lazyLoad = true)
    {
        return new \App\Util\Trans();
    }

    /**
     * Gets the private 'App\View\FrontRenderInterface' shared autowired service.
     *
     * @return \App\View\FrontRender
     */
    protected function getFrontRenderInterfaceService($lazyLoad = true)
    {
        return $this->privates['App\\View\\FrontRenderInterface'] = new \App\View\FrontRender(($this->services['Symfony\\Component\\HttpFoundation\\Request'] ?? $this->getRequestService()), ($this->services['Symfony\\Component\\HttpFoundation\\Response'] ?? ($this->services['Symfony\\Component\\HttpFoundation\\Response'] = new \Symfony\Component\HttpFoundation\Response())), new \League\Plates\Engine('C:\\xampp\\htdocs\\ninjaCoder/resources/views/'), ($this->privates['App\\Util\\AppSession'] ?? $this->getAppSessionService()), $this->getTransService());
    }

    public function getParameter($name)
    {
        $name = (string) $name;

        if (!(isset($this->parameters[$name]) || isset($this->loadedDynamicParameters[$name]) || array_key_exists($name, $this->parameters))) {
            throw new InvalidArgumentException(sprintf('The parameter "%s" must be defined.', $name));
        }
        if (isset($this->loadedDynamicParameters[$name])) {
            return $this->loadedDynamicParameters[$name] ? $this->dynamicParameters[$name] : $this->getDynamicParameter($name);
        }

        return $this->parameters[$name];
    }

    public function hasParameter($name): bool
    {
        $name = (string) $name;

        return isset($this->parameters[$name]) || isset($this->loadedDynamicParameters[$name]) || array_key_exists($name, $this->parameters);
    }

    public function setParameter($name, $value): void
    {
        throw new LogicException('Impossible to call set() on a frozen ParameterBag.');
    }

    public function getParameterBag(): ParameterBagInterface
    {
        if (null === $this->parameterBag) {
            $parameters = $this->parameters;
            foreach ($this->loadedDynamicParameters as $name => $loaded) {
                $parameters[$name] = $loaded ? $this->dynamicParameters[$name] : $this->getDynamicParameter($name);
            }
            $this->parameterBag = new FrozenParameterBag($parameters);
        }

        return $this->parameterBag;
    }

    private $loadedDynamicParameters = [];
    private $dynamicParameters = [];

    private function getDynamicParameter(string $name)
    {
        throw new InvalidArgumentException(sprintf('The dynamic parameter "%s" must be defined.', $name));
    }

    protected function getDefaultParameters(): array
    {
        return [
            'viewsDir' => 'C:\\xampp\\htdocs\\ninjaCoder/resources/views/',
            'salt' => '4e46c93890f89ff4dd3e41513c377ba11fa495a42d26ab1342c49086ae7c630fc91e0d',
            'minLength' => 5,
            'session.maxlife' => 1800,
            'session_options' => [
                'name' => 'ninjaCoderSessID',
                'use_strict_mode' => true,
                'gc_probability' => 0,
                'cookie_lifetime' => 1810,
                'cookie_samesite' => 'lax',
                'sid_length' => 48,
                'sid_bits_per_character' => 6,
            ],
        ];
    }
}
