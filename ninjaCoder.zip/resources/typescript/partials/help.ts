function al() : void {
    alert('someThinf');
}

export {al};