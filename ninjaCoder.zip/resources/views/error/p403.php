<?php $this->layout('layouts/errors', [
    'errCode' => 403,
    'errMessage' => 'Forbidden'
])?>