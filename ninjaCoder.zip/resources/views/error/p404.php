<?php $this->layout('layouts/errors', [
    'errCode' => 404,
    'errMessage' => 'Not Found'
])?>