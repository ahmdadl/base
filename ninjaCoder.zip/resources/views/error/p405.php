<?php $this->layout('layouts/errors', [
    'errCode' => 405,
    'errMessage' => 'Not Allowed'
])?>