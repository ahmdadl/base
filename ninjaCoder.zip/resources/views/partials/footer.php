<footer class='footer'>
    <p>copy <?=date('Y')?> to <?=strtoupper('ahmed adel')?></p>
</footer>